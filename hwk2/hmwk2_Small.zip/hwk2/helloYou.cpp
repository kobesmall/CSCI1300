
#include <iostream>

using namespace std;

int main(){
    string nm;
    cout<< "Enter your name:"<< endl;
    cin >> nm;
    cout << "Hello, " << nm << "!" << endl;
}