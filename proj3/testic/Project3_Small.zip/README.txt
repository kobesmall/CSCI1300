

Project 3 - README
CSCI 1300 Spring 21
Kobe Small


Project Name - Murder Mystery Game

this is a murder mystery game, interview guest at a house and collect evidece to find whos the murder

Required Text Files:
Items.txt
Rooms.txt
Roles.txt
gameResult.txt

Compile and Run:

g++ -std=c++11 unity.cpp
./a.out
(Make sure that all the files are present in the directory)


NOTES:
## To run game compile unity.cpp
## DO NOT enter any strings or chars for menu options I didn't handle failed input buffer you will be stuck in infinite loop, kill terminal and restart
## once you accuse someone the game is over check gameResults.txt for the outcome


Author:
    Kobe Small

// CS1300 Spring 2021
// Author: Kobe Small
// Recitation: 122 – Sourav Chakraborty
// Project 3 