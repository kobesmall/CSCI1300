


#ifndef ITEM_H
#define ITEM_H
#include <iostream>

using namespace std;


class  Item
{
    private:
        string name;
        string detail;
    public:
        Item();
        Item(string name, string detail);
        string getname();
        string getDetail();



};


#endif