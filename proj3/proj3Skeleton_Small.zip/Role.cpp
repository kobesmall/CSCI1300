




#include <iostream>
#include "Role.h"



using namespace std;

Role::Role(){
    name = "";
    story = "";
    alaby = "";
}

Role::Role(string nm, string st, string al, Item it){
    name = nm;
    story = st;
    alaby = al;
    inventory[0]=it;
}

string Role::getName(){
    return name;
}

string Role::getAlaby(){
  return alaby;
}


string Role::getStory(){
    return story;
}

string Role::getItem(){
    return inventory[0].getname();
}

void Role::giveItem(Item it){
    inventory[0]=it;
}

string Role::getRoom(){

    return room;
}

void Role::move(){
                                //will move character to a different room *randomly by changing room string 
                                //and updating that rooms characters the person is in
}