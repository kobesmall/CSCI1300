


#include <iostream>
#include "PI.h"


using namespace std;


PI::PI(){
    name = "";
}

PI::PI(string name){

    this->name = name;

}

string PI::getName(){

    return name;
}

string PI::getRoom(){

    return room; 
}

void PI::setRoom(string rm){
    room = rm;
}

void PI::examine(){
                        //used to get an items detail, see whos in a room and to find items in a room

}

void PI::accuse(){
                        //used to make final descision about who the killer is only can be used twice during game

}

void PI::move(){
                        //move the users player into a different room allwoing them to find more items and characters
                        //not random and will end a *turn phase

}

void question(){
                        //used to access a charaters story or alaby 
                        

}

void writeDown(){
                        //used to store items detail and charachter stories/alabys to refer to later
}

void checkTime(){
                        //used to check the time in the game 
}
