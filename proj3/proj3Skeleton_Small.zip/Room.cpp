

#include "Room.h"
#include <iostream>


using namespace std;

Room::Room(){
    name = "";
}

Room::Room(string name, Item it){

    this->name = name;
    item = it;
}

string Room::getName(){

    return name;
}


Item Room::getItem(){

    return item;
}

string Room::getCharacterList(){

    return "TODO" ;                               //returns a string list of every charcter in a room
}