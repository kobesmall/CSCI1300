


#include <iostream>
#include "Item.h"


using namespace std;


Item::Item(){
    name = "";
    detail = "";
}

Item::Item(string nm, string dt){
    name = nm;
    detail = dt;

}

string Item::getDetail(){
    return detail;
}

string Item::getname(){
    return name;
}