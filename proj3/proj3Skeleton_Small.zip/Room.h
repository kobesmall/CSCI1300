

#ifndef ROOM_H
#define ROOM_H
#include <iostream>
#include "Role.h"
#include "Item.h"


using namespace std;


class Room
{
    private:
        string name;
        Item item;
        Role list[10];
    
    public:
        Room();
        Room(string name, Item item);
        string getName();
        Item   getItem();
        string getCharacterList();



};


#endif