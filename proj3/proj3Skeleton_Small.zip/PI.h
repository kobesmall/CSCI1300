


#ifndef PI_H
#define PI_H
#include "Item.h"
#include <iostream>

using namespace std;


class PI
{
    private:
        string name;
        Item inventory[10];
        string notebook[10];
        string room;


    public:
        PI();
        PI(string name);
        void examine();
        void accuse();
        void move();
        void question();
        void writeDown();
        void checkTime();
        string getName();
        string getRoom();
        void setRoom(string room);




};


#endif